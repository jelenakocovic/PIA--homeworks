<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB Register</title>
    </head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="script.js" type="text/javascript"></script>
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <body>

        <?php
        session_start();
        include('config.php');
        if (isset($_POST['register'])) {

            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];

            $roleId = 2; //user
            $query = $conn->prepare("SELECT * FROM users WHERE username = ?");
            $query->bind_param('s', $username);
            $query->execute();
            $result = $query->get_result()->fetch_all(MYSQLI_ASSOC);
            $num = count($result);
            if ($num > 0) {
                $registerMessage = '<p class="text-error">The username is already registered!</p>';
            } else {
                $query->close();
                $stmt = $conn->prepare("INSERT INTO users(firstName, lastName, email, username, password, roleId) VALUES (?, ?, ?, ?, ?, ?)");

                $stmt->bind_param("sssssi", $firstname, $lastname, $email, $username, $password, $roleId);
                $result = $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $registerMessage = '<p class="text-success">Your registration was successful!</p>';
                    //header('Location: login.php');
                } else {
                    $registerMessage = '<p class="text-error">Something went wrong!</p>';
                }
            }
        }
        ?>
        <div class="row min-vh-100">

            <div class="col-3 bg-dark text-white">
                <div class="navside position-absolute w-100 p-4 align-items-center ">
                    <h1>IMDB</h1>
                    <br>
                    <h3>Register Page</h3>
                </div>
            </div>

            <div class="col-9 p-0">
                <div class="position-absolute w-100 mx-0 p-5">
                    <div class="position-relative float-right">
                        <button type="button" onclick="goTo('login')" class="btn btn-secondary">Login</button>
                    </div>
                </div>
                <div class="register-form position-absolute m-0 w-50">
                    <form action="" method="post">
                        <div class="form-group">
                            <label>First name:</label>
                            <input type="text" class="form-control" name="firstname" pattern="[a-zA-Z0-9]+" placeholder="First Name" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" class="form-control" name="lastname"  placeholder="Last Name">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label>User Name</label>
                            <input type="text" class="form-control" name="username" pattern="[a-zA-Z0-9]+" minlength="4" maxlength="10" placeholder="User Name" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder="Password must contain at least number and uppercase and lowercase letter, and at least 8 characters" required>
                        </div>

                        <button type="submit" class="btn btn-yellow" name="register" value="register">Register</button>
                    </form>

                </div>

                <div class="w-50 p-4 h3">
                    <?php
                    if (isset($registerMessage)) {
                        echo $registerMessage;
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
