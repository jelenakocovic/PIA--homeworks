
<?php

include('config.php');
$movieId = $_GET['movieId'];

$query = $conn->prepare("DELETE FROM movies WHERE id = ?");
$query->bind_param('i', $movieId);
$query->execute();

if ($query->affected_rows) {
    header('Location: admin_page.php');
}
?>