<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB Login</title>
    </head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="script.js" type="text/javascript"></script>
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <body>
        <?php
        include('config.php');
        session_start();
        $_SESSION = array();
        if (isset($_POST['login'])) {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param('ss', $username, $username);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $loginMessage = "";
            $num = count($result);
            if ($num > 0) {
                $value = $result[0];

                if ($password == $value['password']) {
                    $_SESSION['user_id'] = $value['id'];

                    if ($value['roleId'] == 1) {
                        header('Location: admin_page.php');
                    } else if ($value['roleId'] == 2) {
                        header('Location: user_page.php');
                    }
                } else {
                    $loginMessage = '<p class="text-danger">Username/password combination is wrong!</p>';
                }
            } else {
                $loginMessage = '<p class="text-danger">Username doesnt exist!</p>';
            }
        }
        ?>
        <div class="row min-vh-100">

            <div class="col-3 bg-dark text-white">
                <div class="navside position-absolute w-100 p-4 align-items-center ">
                    <h1>IMDB</h1>
                    <br>
                    <h3>Login Page</h3>
                    <p>Login or register from here to access.</p>
                </div>
            </div>

            <div class="col-9 p-0">
                <div class="position-absolute w-100 mx-0 p-5">
                    <div class="position-relative float-right">
                        <button type="button" onclick="goTo('register')" class="btn btn-secondary">Register</button>
                    </div>
                </div>
                <div class="login-form position-absolute m-0 w-50">
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Username or email address</label>
                            <input type="text" class="form-control" name="username" placeholder="Username or email address" required >
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password" pattern="[a-zA-Z0-9]+" placeholder="Password" required >
                        </div>

                        <button type="submit" class="btn btn-yellow" name="login" value="login">Login</button>
                    </form>
                </div>

                <div class="w-50 p-4 h3">
                    <?php
                    if (isset($loginMessage)) {
                        echo $loginMessage;
                    }
                    ?>
                </div>
            </div>
        </div>

    </body>
</html>
