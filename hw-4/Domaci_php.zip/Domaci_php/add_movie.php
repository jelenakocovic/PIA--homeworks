<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB New movie</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="script.js" type="text/javascript"></script>
        <script src="script.js" type="text/javascript"></script>
        <link href="style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow:auto;">
        <?php
        include('config.php');
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        } else {
            if (isset($_POST['add'])) {
                $title = $_POST['title'];
                $description = $_POST['description'];
                $genre = $_POST['genre'];
                $cast = $_POST['cast'];
                $director = $_POST['director'];
                $screenwriter = $_POST['screenwriter'];
                $year = $_POST['year'];
                $production = $_POST['production'];
                $duration = $_POST['duration'];
                $ratingValue = $_POST['ratingValue'];
                $numOfRatings = $_POST['numOfRatings'];

                $image='';
                $tmpname = $_FILES['poster']['tmp_name'];
                if (!empty($tmpname)) {
                    $image = addslashes(file_get_contents($tmpname));
                }
                $query = "INSERT INTO movies(title, description, genre, cast, director, screenwriter, year, production, duration, ratingValue, numOfRatings, poster)"
                        . " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '".$image."')";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('ssssssisidi', $title, $description, $genre, $cast, $director, $screenwriter, $year, $production, $duration, $ratingValue, $numOfRatings);
                $stmt->execute();
                if ($stmt->affected_rows > 0) {
                    header('Location: admin_page.php');
                }
            } else if (isset($_POST['close'])) {
                header('Location: admin_page.php');
            }
            ?>
            <div class="container mt-2">
                <div class="row w-100 mx-0">
                    <div class="col-9 p-0 ">
                        <img src="imdb_logo.png" class="img-fluid" width="15%">
                    </div>
                    <div class="col-3">
                        <form action="logout.php" method="post">
                            <div class="w-100 p-2 ">
                                <div class="position-relative float-right">
                                    <button type="submit" class="btn btn-secondary" name="logout" value="logout">Logout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">


                    <div class="col-12 h-100">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class=" col-6 ">
                                    <h3>Add movie</h3>
                                </div>
                                <div class="col-6">
                                    <button type="submit" class="close float-right" name="close" value="close" aria-label="Close">
                                        <span class="h2" aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label for="title" class="col-form-label">Title:</label>
                                <input type="text" class="form-control" pattern="[a-z' 'A-Z]+" id="title" name="title">
                            </div>
                            <div class="form-group">
                                <label for="description" class="col-form-label">Description:</label>
                                <input type="text" class="form-control" pattern="[a-z' 'A-Z0-9'.'',']*" id="description" name="description">
                            </div>
                            <div class="form-group">
                                <label for="genre" class="col-form-label">Genre:</label>
                                <input type="text" class="form-control" pattern="[a-zA-Z' ']*" id="genre" name="genre">
                            </div>
                            <div class="form-group">
                                <label for="screenwriter" class="col-form-label">Screenwriter:</label>
                                <input type="text" class="form-control" id="screenwriter" pattern="[a-z' 'A-Z0-9'.'',']*" name="screenwriter">
                            </div>
                            <div class="form-group">
                                <label for="director" class="col-form-label">Director:</label>
                                <input type="text" class="form-control" id="director"  pattern="[a-z' 'A-Z0-9'.'',']*"  name="director">
                            </div>
                            <div class="form-group">
                                <label for="production" class="col-form-label">Production:</label>
                                <input type="text" class="form-control" id="production" pattern="[a-z' 'A-Z0-9'.'',']*"  name="production">
                            </div>
                            <div class="form-group">
                                <label for="production" class="col-form-label">Cast:</label>
                                <input type="text" class="form-control" id="cast" pattern="[a-z' 'A-Z0-9'.'',']*"  name="cast">
                            </div>
                            <div class="form-group">
                                <label for="year" class="col-form-label">Year:</label>
                                <input type="text" class="form-control" id="year" pattern="[0-9]+"  name="year">
                            </div>
                            <div class="form-group">
                                <label for="duration" class="col-form-label">Duration in minutes:</label>
                                <input type="text" class="form-control" id="duration" pattern="[0-9]+"  name="duration">
                            </div>
                            <div class="form-group">
                                <label for="ratingValue" class="col-form-label">Rating:</label>
                                <input type="text" pattern="^\d+\.\d{0,2}$" class="form-control"  id="ratingValue" name="ratingValue">
                            </div>
                            <div class="form-group">
                                <label for="numOfRatings" class="col-form-label">Number of ratings:</label>
                                <input type="text" pattern="[0-9]+" class="form-control" id="numOfRatings" name="numOfRatings">
                            </div>
                            <div class="form-group">
                                <label for="poster" class="col-form-label"> Select image to upload:</label>
                                <input type="file" accept="image/png" class="form-control" id="poster" name="poster">
                            </div>
                            <button type="submit" class="btn btn-success float-right" name="add" value="add">Add movie</button>
                        </form>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </body>
</html>
