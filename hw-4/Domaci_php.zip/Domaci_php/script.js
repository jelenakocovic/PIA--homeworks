function goTo(page) {
    var file = page + '.php';
    window.location.href = file;
}
