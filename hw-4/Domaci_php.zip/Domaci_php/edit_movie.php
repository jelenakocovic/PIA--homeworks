<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB Edit movie</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="script.js" type="text/javascript"></script>
        <script src="script.js" type="text/javascript"></script>
        <link href="style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow:auto;">
        <?php
        include('config.php');
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        } else {
            if (isset($_GET['editMovie'])) {
                $movieId = $_GET['editMovie'];
                $stmt = $conn->prepare("SELECT * FROM movies WHERE id = ?");
                $stmt->bind_param('i', $movieId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                if (count($result) > 0) {
                    $movie = $result[0];
                } else {
                    header('Location: admin_page.php');
                }
            }


            if (isset($_POST['edit'])) {
                $title = $_POST['title'];
                $description = $_POST['description'];
                $genre = $_POST['genre'];
                $cast = $_POST['cast'];
                $director = $_POST['director'];
                $screenwriter = $_POST['screenwriter'];
                $year = $_POST['year'];
                $production = $_POST['production'];
                $duration = $_POST['duration'];
                $ratingValue = $_POST['ratingValue'];
                $numOfRatings = $_POST['numOfRatings'];

                $image = $movie['poster'];
                $tmpname = $_FILES['poster']['tmp_name'];
                

                $query = "UPDATE movies SET title=\"" . $title . "\", description=\"" .
                        $description . "\", genre=\"" . $genre . "\", director=\"" . $director .
                        "\", screenwriter=\"" . $screenwriter . "\", year=" . $year . ", production=\"" .
                        $production . "\", duration=" . $duration . ", cast= \"" . $cast . "\", ratingValue=" . $ratingValue . ", numOfRatings=" . $numOfRatings;
                
                if (!empty($tmpname)) {
                    $image = addslashes(file_get_contents($tmpname));
                    
                    $query.= ", poster='".$image."' WHERE id=". $movieId;
                }else{
                    $query.= " WHERE id=". $movieId;
                }

                $stmt = $conn->prepare($query);
                $stmt->execute();
                unset($_GET['editMovie']);
                if ($stmt->affected_rows > 0) {
                    header('Location: admin_page.php');
                }
            } else if (isset($_POST['close'])) {
                header('Location: admin_page.php');
            }
            ?>
            <div class="container mt-2">
                <div class="row w-100 mx-0">
                    <div class="col-9 p-0 ">
                        <img src="imdb_logo.png" class="img-fluid" width="15%">
                    </div>
                    <div class="col-3">
                        <form action="logout.php" method="post">
                            <div class="w-100 p-2 ">
                                <div class="position-relative float-right">
                                    <button type="submit" class="btn btn-secondary" name="logout" value="logout">Logout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">

                    <div class="col-12 h-100">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class=" col-6 ">
                                    <h3>Edit movie</h3>
                                </div>
                                <div class="col-6">
                                    <button type="submit" class="close float-right" name="close" value="close" aria-label="Close">
                                        <span class="h2" aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                            <hr>
                            <div class="form-group">
                                <label for="title" class="col-form-label">Title:</label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo $movie['title']; ?>"/>
                            </div>
                            <div class="form-group">
                                <label for="description" class="col-form-label">Description:</label>
                                <input type="text" class="form-control" id="description" name="description" value="<?php echo $movie['description']; ?>"/>
                            </div>
                            <div class="form-group">
                                <label for="genre" class="col-form-label">Genre:</label>
                                <input type="text" class="form-control" id="genre" name="genre" value="<?php echo $movie['genre']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="screenwriter" class="col-form-label">Screenwriter:</label>
                                <input type="text" class="form-control" id="screenwriter" name="screenwriter" value="<?php echo $movie['screenwriter']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="director" class="col-form-label">Director:</label>
                                <input type="text" class="form-control" id="director" name="director" value="<?php echo $movie['director']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="production" class="col-form-label">Production:</label>
                                <input type="text" class="form-control" id="production" name="production" value="<?php echo $movie['production']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="Cast" class="col-form-label">Cast:</label>
                                <input type="text" class="form-control" id="cast" name="cast" value="<?php echo $movie['cast']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="year" class="col-form-label">Year:</label>
                                <input type="text" class="form-control" id="year" name="year" value="<?php echo $movie['year']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="duration" class="col-form-label">Duration in minutes:</label>
                                <input type="text" class="form-control" id="duration" name="duration" value="<?php echo $movie['duration']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="ratingValue" class="col-form-label">Rating:</label>
                                <input type="number" pattern="[0-9]+\." min="0" max="10" step="0.01" class="form-control" id="duration" name="ratingValue" value="<?php echo $movie['ratingValue']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="numOfRatings" class="col-form-label">Number of ratings:</label>
                                <input type="number" pattern="[0-9]*" class="form-control" id="duration" name="numOfRatings" value="<?php echo $movie['numOfRatings']; ?>">
                            </div>
                            <div class="form-group">
                                <?php if ($movie['poster']) {
                                    ?>
                                    <img class="img-thumbnail" width="100px" height="100px" src="data:image/png;base64,<?php echo base64_encode($movie['poster']); ?> "> 
                                    <?php
                                }
                                ?>

                                <label for="poster" class="col-form-label"> Select image to upload:</label>
                                <input type="file" accept="image/png" class="form-control" id="poster" name="poster">
                            </div>
                            <button type="submit" class="btn btn-success float-right" name="edit" value="edit">Edit movie</button>
                        </form>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </body>
</html>
