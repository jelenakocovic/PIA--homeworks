<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB Movie</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="script.js" type="text/javascript"></script>
        <script src="script.js" type="text/javascript"></script>
        <link href="style.css" rel="stylesheet" type="text/css"/>

        <script>
            function setRating(value) {
                var arr = document.getElementsByTagName('span');
                for (var i = 0, max = arr.length; i < max; i++) {
                    console.log(arr[i]);
                    arr[i].style = 'color:black;';
                }
                document.getElementById('ratingBtn').value = value;

                for (var i = 0, max = value; i <= max + 1; i++) {
                    arr[i].style = 'color:#FFBA00;';
                }
            }
        </script>
    </head>
    <body style="overflow:auto;">
        <?php
        include('config.php');
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit;
        } else {
            if (isset($_GET['displayMovie'])) {
                $movieId = $_GET['displayMovie'];
                $stmt = $conn->prepare("SELECT * FROM movies WHERE id = ?");
                $stmt->bind_param('i', $movieId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                if (count($result) > 0) {
                    $movie = $result[0];
                } else {
                    header('Location: user_page.php?');
                }

                if (isset($_POST['close'])) {
                    header('Location: user_page.php');
                } else if (isset($_POST['rating'])) {
                    echo $_POST['rating'];

                    $numOfRatings = $movie['numOfRatings'] + 1;
                    $average = ($movie['ratingValue'] * $movie['numOfRatings'] + $_POST['rating']) / $numOfRatings;

                    $query = "UPDATE movies SET ratingValue=" . $average . ", numOfRatings=" .
                            $numOfRatings . " WHERE id=" . $movieId;
                    echo $query;
                    $stmt = $conn->prepare($query);
                    $stmt->execute();
                    if ($stmt->affected_rows > 0) {
                        header('Location: movie.php?displayMovie=' . $movieId);
                    }
                }
            }
            ?>
            <div class="container mt-2">
                <div class="row w-100 mx-0">
                    <div class="col-9 p-0 ">
                        <img src="imdb_logo.png" class="img-fluid" width="15%">
                    </div>
                    <div class="col-3">
                        <form action="logout.php" method="post">
                            <div class="w-100 p-2 ">
                                <div class="position-relative float-right">
                                    <button type="submit" class="btn btn-secondary" name="logout" value="logout">Logout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">

                    <div class="col-12 h-100">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-6"></div>
                                <div class="col-6">
                                    <button type="submit" class="close float-right" name="close" value="close" aria-label="Close">
                                        <span class="h2" aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <hr>
                        <div class="row">
                            <div class="col-3 d-inline">
                                <?php if ($movie['poster']) {
                                    ?>
                                    <img class="img-thumbnail" width="200px" height="200px" src="data:image/png;base64,<?php echo base64_encode($movie['poster']); ?> "> 
                                    <?php
                                } else {
                                    ?>

                                    <img class="img-thumbnail" width="200px" height="200px" src="imageNotAvailable.png" alt=""/>
                                    <?php
                                }
                                ?>

                            </div>
                            <div class="col-9 h2 d-inline">
                                <label for="title" class="col-form-label">
                                    <?php
                                    echo $movie['title'];
                                    echo "(" . $movie['year'] . ")";
                                    ?>
                                </label>
                                <br>
                                <?php
                                echo "<p class='underline h6'>" . $movie['duration'] . "  " . $movie['genre'] . "</p>";
                                ?>
                                <br>
                                <?php echo $movie['ratingValue']; ?>
                                <span class="fa fa-star checked yellow"></span>
                                <?php
                                echo "<p class='underline h5'>Votes: " . $movie['numOfRatings'] . "</p>";
                                ?>
                                <form action="" method="post">
                                    <div class="rating">
                                        <span class="fa fa-star" onclick="setRating(1)"></span>
                                        <span class="fa fa-star" onclick="setRating(2)"></span>
                                        <span class="fa fa-star" onclick="setRating(3)"></span>
                                        <span class="fa fa-star" onclick="setRating(4)"></span>
                                        <span class="fa fa-star" onclick="setRating(5)"></span>
                                        <span class="fa fa-star" onclick="setRating(6)"></span>
                                        <span class="fa fa-star" onclick="setRating(7)"></span>
                                        <span class="fa fa-star" onclick="setRating(8)"></span>
                                        <span class="fa fa-star" onclick="setRating(9)"></span>
                                        <span class="fa fa-star" onclick="setRating(10)"></span>
                                    </div>

                                    <button id="ratingBtn" type="submit" class="btn btn-secondary" name="rating" aria-label="Close">
                                        Rate
                                    </button>
                                </form>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-12">
                                <div class="text">
                                    <?php echo $movie['description']; ?>
                                </div>
                                <br>
                                <label for="screenwriter" class="font-weight-bold">Screenwriter: </label><?php echo $movie['screenwriter']; ?>
                                <br>
                                <label for="director" class="font-weight-bold">Director: </label><?php echo $movie['director']; ?>
                                <br>
                                <label for="production" class="font-weight-bold">Production:</label> <?php echo $movie['production']; ?>
                                <br>
                                <label for="Cast" class="font-weight-bold">Cast:</label> <?php echo $movie['cast']; ?>

                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </body>
</html>
