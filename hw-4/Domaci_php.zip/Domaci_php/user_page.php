<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title>IMDB Movies</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="script.js" type="text/javascript"></script>
        <script src="script.js" type="text/javascript"></script>
        <link href="style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow:auto;">
        <?php
        include('config.php');
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php');
            exit;
        } else {
            if (isset($_GET['search'])) {
                $searchValue = $_GET['searchValue'];
                $query = "SELECT * FROM movies WHERE title LIKE '%" . $searchValue . "%' OR genre LIKE '%" . $searchValue . "%'";
            } else if (!isset($_GET['search']) || isset($_GET['clear'])) {
                $_GET['searchValue'] = "";
                $query = "SELECT * FROM movies";
            }

            $stmt = $conn->prepare("SELECT * FROM movies");
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            ?>
            <div class="container mt-2">
                <div class="row w-100 mx-0">
                    <div class="col-9 p-0 ">
                        <img src="imdb_logo.png" class="img-fluid" width="15%">
                    </div>
                    <div class="col-3">
                        <form action="logout.php" method="post">
                            <div class="w-100 p-2 ">
                                <div class="position-relative float-right">
                                    <button type="submit" class="btn btn-secondary" name="logout" value="logout">Logout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">

                    <div class="col-9 h-100">
                        <form action="" method="get">
                            <div class="input-group">
                                <input type="search" class="form-control" id="search" name="searchValue" placeholder="Enter genre or title..." value="<?php echo $_GET['searchValue'] ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-yellow" name="search" value="search">Search</button>
                                </div>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-danger" name="clear" value="clear">Clear</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row mt-5 h-100">
                    <div class="col-12 h-100">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col-2"></th>
                                    <th scope="col-2">#</th>
                                    <th scope="col-2">Title</th>
                                    <th scope="col-2">IMDb Rating</th>
                                    <th scope="col-2"></th>
                                    <th scope="col-2"></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                for ($i = 0; $i < count($result); $i++) {
                                    $row = $result[$i];
                                    ?>
                                    <tr>
                                        <th>
                                            <?php if ($row['poster']) {
                                                ?>
                                                <img class="img-thumbnail" width="100px" height="100px" src="data:image/png;base64,<?php echo base64_encode($row['poster']); ?> "> 
                                                <?php
                                            } else {
                                                ?>

                                                <img class="img-thumbnail" width="100px" height="100px" src="imageNotAvailable.png" alt=""/>
                                                <?php
                                            }
                                            ?>
                                        </th>
                                        <th><?php echo $row['id']; ?></th>
                                        <th>
                                            <form action="movie.php" method="get">

                                                    <div class="h-3">
                                                        <button type="submit" class="noStyle" name="displayMovie" value=" <?php echo $row['id']; ?>"> 
                                                            <?php echo $row['title'] . "(" . $row['year'] . ")"; ?>
                                                        </button>
                                                    </div>
                                            </form>
                                        </th>
                                        <th><?php echo $row['ratingValue']; ?>
                                            <span class="fa fa-star checked yellow"></span>
                                        </th>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </body>
</html>
